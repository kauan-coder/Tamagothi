
> Abrir essa página em [https://kauan-coder.github.io/tamagorabbit/](https://kauan-coder.github.io/tamagorabbit/)

## Usar como extensão

Este repositório pode ser adicionado como **extensão** no MakeCode.

* abrir [https://makecode.microbit.org/](https://makecode.microbit.org/)
* clique em **Novo Projeto**
* clique em **Extensões** em baixo do menu com ícone de engrenagem
* procure por **https://github.com/kauan-coder/tamagorabbit** e importe

## Editar este projeto ![Ícone de estado da compilação](https://github.com/kauan-coder/tamagorabbit/workflows/MakeCode/badge.svg)

Para editar este repositório no MakeCode.

* abrir [https://makecode.microbit.org/](https://makecode.microbit.org/)
* clique em **Importar** e depois clique em **Importar URL**
* cole **https://github.com/kauan-coder/tamagorabbit** e clique em importar

## Pré-visualização de blocos

"Essa imagem mostra o bloco de códigos da última confirmação no "mestre"".
Esta imagem pode demorar alguns minutos para atualizar.

![Uma visão renderizada dos blocos](https://github.com/kauan-coder/tamagorabbit/raw/master/.github/makecode/blocks.png)

#### Metadados (usados para pesquisa, renderização)

* for PXT/microbit
<script src="https://makecode.com/gh-pages-embed.js"></script><script>makeCodeRender("{{ site.makecode.home_url }}", "{{ site.github.owner_name }}/{{ site.github.repository_name }}");</script>
