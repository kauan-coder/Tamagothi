input.onButtonPressed(Button.A, function () {
    for (let index = 0; index < 2; index++) {
        basic.showLeds(`
            . . # . .
            . # # # .
            . # # # .
            . # # # .
            . # . # .
            `)
        basic.showLeds(`
            . # # # .
            . # # # .
            . # # # .
            . # . # .
            . . . . .
            `)
        basic.showLeds(`
            . # # # .
            . # # # .
            . # . # .
            . . . . .
            . . . . .
            `)
        basic.showLeds(`
            . # # # .
            . # . # .
            . . . . .
            . . . . .
            . . . . .
            `)
        basic.showLeds(`
            . # . # .
            . . . . .
            . . . . .
            . . . . .
            . . . . .
            `)
        basic.showLeds(`
            . . . . .
            . . . . .
            . . . . .
            . . . . .
            . . . . .
            `)
    }
    music.startMelody(music.builtInMelody(Melodies.PowerUp), MelodyOptions.Once)
    basic.showIcon(IconNames.Happy)
    basic.showIcon(IconNames.Rabbit)
    music.startMelody(music.builtInMelody(Melodies.Blues), MelodyOptions.Forever)
})
input.onGesture(Gesture.Shake, function () {
    music.startMelody(music.builtInMelody(Melodies.Funeral), MelodyOptions.Forever)
    basic.showIcon(IconNames.Surprised)
    basic.showIcon(IconNames.Surprised)
    basic.showIcon(IconNames.Rabbit)
    basic.showLeds(`
        . # . # .
        . # . # .
        . # # # #
        . # # . #
        . # # # #
        `)
    basic.showLeds(`
        . . # . #
        . . # . #
        . . # # #
        . . # # .
        . . # # #
        `)
    basic.showLeds(`
        . . . # .
        . . . # .
        . . . # #
        . . . # #
        . . . # #
        `)
    basic.showLeds(`
        . . . . #
        . . . . #
        . . . . #
        . . . . #
        . . . . #
        `)
    basic.showString("ELE FUGIU")
})
input.onButtonPressed(Button.AB, function () {
    music.startMelody(music.builtInMelody(Melodies.Entertainer), MelodyOptions.Once)
    basic.showLeds(`
        . . # # #
        # # # # #
        . . # # #
        . . # . #
        . . # . #
        `)
    basic.showIcon(IconNames.Happy)
    basic.showLeds(`
        . . # # #
        # # # # #
        . . # # #
        . . # . #
        . . # . #
        `)
    basic.showIcon(IconNames.Happy)
    basic.showIcon(IconNames.Happy)
    basic.showIcon(IconNames.Happy)
    music.startMelody(music.builtInMelody(Melodies.Blues), MelodyOptions.Forever)
    basic.showIcon(IconNames.Rabbit)
})
input.onButtonPressed(Button.B, function () {
    music.startMelody(music.builtInMelody(Melodies.Punchline), MelodyOptions.Once)
    basic.showLeds(`
        # # # # #
        . . . # .
        . . # . .
        . # . . .
        # # # # #
        `)
    basic.showLeds(`
        . # # # #
        . . . # .
        . . # . .
        . # # # #
        . . . . .
        `)
    basic.showLeds(`
        # # # # #
        . . . # .
        . . # . .
        . # . . .
        # # # # #
        `)
    basic.showIcon(IconNames.Happy)
    basic.showIcon(IconNames.Happy)
    basic.showIcon(IconNames.Happy)
    music.startMelody(music.builtInMelody(Melodies.Blues), MelodyOptions.Forever)
    basic.showIcon(IconNames.Rabbit)
})
basic.showIcon(IconNames.Rabbit)
music.startMelody(music.builtInMelody(Melodies.Blues), MelodyOptions.Forever)
